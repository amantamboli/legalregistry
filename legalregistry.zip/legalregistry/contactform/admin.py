from django.contrib import admin
from .models import *

@admin.register(ContactForm)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phonenumber', 'message', 'timestamp')
    search_fields = ('name', 'email', 'phonenumber', 'timestamp')  # Optional: Add fields for searching