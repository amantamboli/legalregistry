from django.shortcuts import render, redirect
from .forms import MyForm
from datetime import datetime, timedelta
from django.contrib import messages

# The first argument will be sent as "message" to the intent extras Bundle
# Retrieve it with intent.getExtras().getString("message")


def form_view(request):
    if request.method == 'POST':
        form = MyForm(request.POST)        
        if form.is_valid():
            
            formObje = form.save(commit=False)
            timezone_offset = timedelta(hours=5, minutes=30)
            utc_now = datetime.utcnow()
            ist_now = utc_now + timezone_offset
            formObje.timestamp = ist_now.strftime("%Y-%m-%d %H:%M:%S")
            formObje.save()
            
            messages.success(request, 'Thank you for your time! We will contact you shortly. Done')
            form = MyForm()  # Redirect to a success page
    else:
        form = MyForm()

    return render(request, 'contactform.html', context={'form': form})